import React from 'react';


class AdminNotice extends React.Component{

    render(){
        return(
            <div>
                管理员中心首页
            </div>
        )
    }
}

export default AdminNotice